<template>
	<view>
		<div align="center" style="position:relative;top:30rpx">
	
				<text style="font-size: 56upx;">今日学习目标：</text>    
		</div>
				<div align="center" style="position:relative;top:100rpx">
						<input style="width: 740rpx;height:400rpx; border-top-style:solid;border-bottom-style: solid;border-left-style: solid;border-right-style: solid;border-top-color:#D3D3D3;border-bottom-color:#D3D3D3;border-left-color:#D3D3D3;border-right-color:#D3D3D3;" type="text" placeholder="请输入任务">  
				</div>
				<div align="center" style="position:relative;top:150rpx">
						<button @click="add" size="mini" style="left: 300rpx">添加任务</button>   
						</div>
				<div align="center" style="position:relative;top:150rpx;left:380rpx;">
						<text style="font-size: 30upx;">要在今晚10点前完成哦！</text>    
						</div>
				<div align="center" style="position:relative;top:160rpx">
						<text style="font-size: 43upx;">今日打卡</text>    
						</div>
						<div align="center" style="position:relative;top:180rpx;left: 50rpx;">
								<text style="font-size: 43upx;">您已经连续打卡</text>    
								</div>
		
	</view>
</template>

<script>
	export default{
		methods:{
			add(){
				uni.showToast({
					title: '添加成功！',
					icon: 'none',    //如果要纯文本，不要icon，将值设为'none'
					duration: 1000    //持续时间为 2秒
				})  

			}
		}
	}
</script>

<style>
.bs{
	border-style: solid;
}
.bs2{
	border-style: dashed;
}
.bs3{
	border-style: dotted;
}
.bs4{	
	border-style: double;
}
</style>
 
<p class="bs">1px 实线 绿色的边框</p><br>
<p class="bs2">2px 虚线 红色的边框</p><br>
<p class="bs3">3px 点线 蓝色的边框</p><br>
<p class="bs4">定义两个边框</p>