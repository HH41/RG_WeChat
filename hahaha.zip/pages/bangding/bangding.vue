<template>
	
	<view>
		<!-- 顶部导航栏 -->
		<view class="horizonal-tab">
			<scroll-view scroll-x="true" scroll-with-animation class="scroll-tab">
				<block v-for="(item,index) in tabBars" :key="index">
					<view class="scroll-tab-item" :class="{'active': tabIndex==index}" 
					@tap="toggleTab(index)">
						{{item.name}}
						<view class="scroll-tab-line"></view>
					</view>
				</block>
			</scroll-view>
		</view>
		
		<!-- 内容区 -->
		<view class="content">
			<!-- 滑块视图 -->
			<swiper :current="tabIndex" @change="tabChange"><!-- current:当前所在滑块的index -->
				<swiper-item >
					<div align="center" style="position:relative;top:150rpx;left:230rpx;">
							<input style="width: 300rpx;height:50rpx; border-top-style:solid;border-bottom-style: solid;border-left-style: solid;border-right-style: solid;border-top-color:#000000;border-bottom-color:#000000;border-left-color:#000000;border-right-color:#000000;" type="text" placeholder="请输入用户名">  
					</div>
					<div align="center" style="position:relative;top:180rpx;left:230rpx;">
							<input style="width: 300rpx;height:50rpx; border-top-style:solid;border-bottom-style: solid;border-left-style: solid;border-right-style: solid;border-top-color:#000000;border-bottom-color:#000000;border-left-color:#000000;border-right-color:#000000;" type="password" placeholder="请输入密码">  
					</div>
					
					<view class="content">{{content}}</view>
				</swiper-item>
				<swiper-item >
					<div align="center" style="position:relative;top:150rpx;left:230rpx;">
							<input style="width: 300rpx;height:50rpx; border-top-style:solid;border-bottom-style: solid;border-left-style: solid;border-right-style: solid;border-top-color:#000000;border-bottom-color:#000000;border-left-color:#000000;border-right-color:#000000;" type="text" placeholder="请输入用户名">  
					</div>
					<div align="center" style="position:relative;top:180rpx;left:230rpx;">
							<input style="width: 300rpx;height:50rpx; border-top-style:solid;border-bottom-style: solid;border-left-style: solid;border-right-style: solid;border-top-color:#000000;border-bottom-color:#000000;border-left-color:#000000;border-right-color:#000000;" type="password" placeholder="请输入密码">  
					</div>
					
					<view class="content">{{content}}</view>
				</swiper-item>
				<swiper-item >
					<div align="center" style="position:relative;top:150rpx;left:230rpx;">
							<input style="width: 300rpx;height:50rpx; border-top-style:solid;border-bottom-style: solid;border-left-style: solid;border-right-style: solid;border-top-color:#000000;border-bottom-color:#000000;border-left-color:#000000;border-right-color:#000000;" type="text" placeholder="请输入用户名">  
					</div>
					<div align="center" style="position:relative;top:180rpx;left:230rpx;">
							<input style="width: 300rpx;height:50rpx; border-top-style:solid;border-bottom-style: solid;border-left-style: solid;border-right-style: solid;border-top-color:#000000;border-bottom-color:#000000;border-left-color:#000000;border-right-color:#000000;" type="password" placeholder="请输入密码">  
					</div>
					
					<view class="content">{{content}}</view>
				</swiper-item>
			</swiper>
		</view>
		
		
	</view>
</template>
 
<script>
	export default {
		data () {
			return {
				
				tabIndex: 0, /* 选中标签栏的序列,默认显示第一个 */
				tabBars:[
					{
						name: 'CSDN',
						id: 'csdn'
					},
					{
						name: 'GitHub',
						id: 'github'
					},
					{
						name: '博客园',
						id: 'bokeyuan'
					}
				]
			}
		},
		
		methods:{
			//切换选项卡
			toggleTab (index) { 
				this.tabIndex=index;
			},
			//滑动切换swiper
			tabChange (e) { 
				console.log(e);
				this.tabIndex=e.detail.current;
			}
		}
	}
	
</script>
 
<style>
	.horizonal-tab{
		
	}
	.horizonal-tab .active{
		color: gray;
	}
	.scroll-tab{
		white-space: nowrap; /* 必要，导航栏才能横向*/
		border-bottom: 1rpx solid #E1FFFF;
		text-align: center;
		background-color:#E1FFFF;
	}
	.scroll-tab-item{
		display: inline-block; /* 必要，导航栏才能横向*/
		margin: 30rpx 50rpx 0 30rpx;
	}
	.active .scroll-tab-line{
		border-bottom: 5rpx solid #C0C0C0;
		border-radius: 100rpx;
		width: 100rpx
	}
	.login-box {
		width: 100%;
		height: 100%;
	}
	
</style>


