<template>
	<view >
		<uni-list :border="false">
			<uni-badge text="1">
				<uni-list-chat
				:avatar-circle="true"
				title="CSDN"
				avatar="/static/logo.png"
				note="您在CSDN订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
			/>
			</uni-badge>  
			<uni-badge text="2" type="success" @click="bindClick">
				<uni-list-chat
				:avatar-circle="true"
				title="博客园"
				avatar="/static/logo.png"
				note="您在博客园订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
			/>
			</uni-badge>
			
			<uni-badge text="2" type="success" @click="bindClick">
				<uni-list-chat
				:avatar-circle="true"
				title="GitHub"
				avatar="/static/logo.png"
				note="您在GitHub订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
				
			/>
			</uni-badge>
			
			<uni-list-chat
				:avatar-circle="true"
				title="CSDN"
				avatar="/static/logo.png"
				note="您在CSDN订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
				
			/>
			<uni-list-chat
				:avatar-circle="true"
				title="博客园"
				avatar="/static/logo.png"
				note="您在博客园订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
				
			/>
			<uni-list-chat
				:avatar-circle="true"
				title="CSDN"
				avatar="/static/logo.png"
				note="您在CSDN订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
			
			/>
			<uni-list-chat
				:avatar-circle="true"
				title="GitHub"
				avatar="/static/logo.png"
				note="您在GitHub订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
				
			/>
			<uni-list-chat
				:avatar-circle="true"
				title="CSDN"
				avatar="/static/logo.png"
				note="您在CSDN订阅的项目有了新的更新,请查收!"
				time="2020.02.30 xxx"
				:clickable="false"
				badge-positon="left"
				badge-text="dot"
				
			/>
		</uni-list>
	</view>
</template>
<script>  
    import uniBadge from "@/components/ay-operate/del_slideLeft.vue"  
    /* import 导入的其它组件 */  

    export default {  
        data() {  
            return { /* ... */ }  
        },  
        components: {  
            uniBadge,  
            /* 其它组件定义 */  
        }  
    }  
</script>
