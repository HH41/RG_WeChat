<template>
	
	<view>
		<!-- 顶部导航栏 -->
		<view class="horizonal-tab">
			<scroll-view scroll-x="true" scroll-with-animation class="scroll-tab">
				<block v-for="(item,index) in tabBars" :key="index">
					<view class="scroll-tab-item" :class="{'active': tabIndex==index}" 
					@tap="toggleTab(index)">
						{{item.name}}
						<view class="scroll-tab-line"></view>
					</view>
				</block>
			</scroll-view>
		</view>
		
		<!-- 内容区 -->
		<view class="content">
			<!-- 滑块视图 -->
			<swiper :current="tabIndex" @change="tabChange"><!-- current:当前所在滑块的index -->
				<swiper-item v-for="(content,index) in contentList" :key="index">
					<view class="content">{{content}}</view>
				</swiper-item>
			</swiper>
		</view>
		
	</view>
</template>
 
<script>
	export default {
		data () {
			return {
				screenHeight: 0,
				tabIndex: 0, /* 选中标签栏的序列,默认显示第一个 */
				contentList: [
					"CSDN",
					"GitHub",
					"博客园",
				],
				tabBars:[
					{
						name: 'CSDN',
						id: 'csdn'
					},
					{
						name: 'GitHub',
						id: 'github'
					},
					{
						name: '博客园',
						id: 'bokeyuan'
					}
				]
			}
		},
		
		methods:{
			//切换选项卡
			toggleTab (index) { 
				this.tabIndex=index;
			},
			//滑动切换swiper
			tabChange (e) { 
				console.log(e);
				this.tabIndex=e.detail.current;
			}
		}
	}
	
</script>
 
<style>
	.horizonal-tab{
		
	}
	.horizonal-tab .active{
		color: gray;
	}
	.scroll-tab{
		white-space: nowrap; /* 必要，导航栏才能横向*/
		border-bottom: 1rpx solid #E1FFFF;
		text-align: center;
		background-color:#E1FFFF;
	}
	.scroll-tab-item{
		display: inline-block; /* 必要，导航栏才能横向*/
		margin: 30rpx 50rpx 0 30rpx;
	}
	.active .scroll-tab-line{
		border-bottom: 5rpx solid #C0C0C0;
		border-radius: 100rpx;
		width: 100r
	}
	.page{
		width: 100%;
		height: 80%;
		background: url("http://m.qpic.cn/psc?/V10Vhpa54XOrOG/45NBuzDIW489QBoVep5mcaNl5HP6RqOKcxBBjK50JECxsSHupx4P8.qMSWqoeU26fVdYB2x.fft3YI0NU5ugMfe66wRkVBoqMHak*5ztybs!/b&bo=EgQ9BwAAAAABFxw!&rf=viewer_4")
		;
		position: absolute;
	}
	.login-box {
		width: 100%;
		height: 100%;
	}
</style>


