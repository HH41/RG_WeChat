<template>
	<view>
		<button @click="get">get</button>
	<view class="content">
		
		
			<text class="title">{{title}}</text>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onLoad()
		{
			
		},
		methods: {
			get() {
				uni.request({
					url:"http://47.107.92.216:5000/oschinanews/titlelist",
					success() {
						console.log(res)
					}
				})
				
			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

</style>
