<template>  
    <view>  
	便签
        <!-- 页面其它组件 -->  
        <!--uni-badge text="1"></uni-badge-->  
        <uni-badge text="2" type="success" @click="bindClick"></uni-badge>  
        <!-- 页面其它组件 -->  
    </view>  
</template>  
<script>  
    import uniBadge from "@/components/ay-operate/del_slideLeft.vue"  
    /* import 导入的其它组件 */  

    export default {  
        data() {  
            return { /* ... */ }  
        },  
        components: {  
            uniBadge,  
            /* 其它组件定义 */  
        }  
    }  
</script>