<template>
	<view>
		<div align="center" style="position:relative;left:680rpx ; top:-10rpx">
		    <text @click="goren" style="font-weight:bold;font-size:80upx;">+</text>
		</div>
	</view>
</template>

<script>
	export default {
		methods:{
			goren() {
				uni.navigateTo({
					url:"../renwu/renwu"
				})
			}
		}
	}
</script>

<style>
</style>
