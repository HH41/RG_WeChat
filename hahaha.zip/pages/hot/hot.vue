<template>
	<view>
			<!-- 顶部导航栏 -->
			<view class="horizonal-tab">
				<scroll-view scroll-x="true" scroll-with-animation class="scroll-tab">
					<block v-for="(item,index) in tabBars" :key="index">
						<view class="scroll-tab-item" :class="{'active': tabIndex==index}" 
						@tap="toggleTab(index)">
							{{item.name}}
							<view class="scroll-tab-line"></view>
						</view>
					</block>
				</scroll-view>
				
			</view>
	
	
		</scroll-view>

		<!--  滑块内容 对应的是顶部选项卡的切换 :current="tabIndex"  设置的是y方向上可以滚动-->
		<swiper :current="tabIndex" @change="onChangeSwiperTab" :style="{height:scrollH+'px'}">
			<swiper-item v-for="(item,index) in tabBars" :key="index">
				
					
					<uni-list  v-for="(item,index1) in productList" :key="index1">        
				        <uni-list-item :title="item"></uni-list-item>            
				    </uni-list>
				
				<scroll-view scroll-y="true" :style="{height:scrollH+'px'}"  @scrolltolower="lower">
					
					{{item.neirong}}
					
				</scroll-view>
			</swiper-item>
		</swiper>
		
		
		
	</view>
</template>

<script>
	import uniList from "@/components/uni-list/uni-list.vue"
	import uniListItem from "@/components/uni-list-item/uni-list-item.vue"
	export default {
		components: {uniList,uniListItem},
		data() {
			return {
				productList: [],
				scrollinto: 'tab0', //默认是第一个推荐 tab 0
				scrollH: 0,//轮播嵌套的内容的滚动区域高度！一定要加这个高度否则动不了
				tabIndex: 0, //当前激活tabIndex
				tabBars: [{
						name: 'CSDN',
						neirong : '1',
					},
					{
						name: 'OSCHINA',
						neirong:'aaaaa',
					},
					{
						name: '博客园',
						neirong:'dddgdz',
					},
				]
			}
		},
		onReady () {
			// 获取可滚动区域的高度：视口高度 - tabbar切换卡高度就是剩余的内容可滚动的。
			//如果你使用取消了原生导航栏，记着把你自定义导航栏的高度也减掉哦
			uni.getSystemInfo({
				success: (res) => {
					this.scrollH = res.windowHeight - uni.upx2px(100)
				}
			})
		},
		onLoad() {
			
		            this.getList();
					
		        },
		methods: {
			// tab选项卡切换轮播
			changeTab(index) {
							// 点击的还是当前数据的时候直接return
							if (this.tabIndex == index) {
								return
							}
							this.tabIndex = index
							// 跟着滑动了要
							this.scrollinto = 'tab' + index
						},
			// 轮播去切换tab列表
			onChangeSwiperTab(e) {
				this.changeTab(e.detail.current)
				// this.tabIndex=e.detail.current
			},
			lower(){
				console.log('滚动到底部了，可以分页请求数据，加载更多');
			},
			toggleTab (index) {
				this.tabIndex=index;
			},
			//滑动切换swiper
			tabChange (e) { 
				console.log(e);
				this.tabIndex=e.detail.current;
			},
			 getList() {         
			                uni.request({
			                    url: "http://47.107.92.216:5000/oschinanews/titlelist", 
								// url: "https://unidemo.dcloud.net.cn/api/news",
			                    method: 'get',
			                    dataType: 'json',
			                    success: (res) => {
			                        console.log(res.data);
			                        this.productList = res.data.titlelist;
									
			                    },                  
			                })
			            }
		}
	}
</script>

<style scoped>
	.horizonal-tab{
		
	}
	.horizonal-tab .active{
		color: gray;
	}
	.scroll-tab{
		white-space: nowrap; /* 必要，导航栏才能横向*/
		border-bottom: 1rpx solid #E1FFFF;
		text-align: center;
		background-color:#E1FFFF;
	}
	.scroll-tab-item{
		display: inline-block; /* 必要，导航栏才能横向*/
		margin: 30rpx 50rpx 0 30rpx;
	}
	.active .scroll-tab-line{
		border-bottom: 5rpx solid #C0C0C0;
		border-radius: 100rpx;
		width: 100r
	} 

</style>
