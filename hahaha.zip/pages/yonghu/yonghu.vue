<template>
	<view>
		<view class="tx-w">
					<view class="tx">
						<image class="tx-img" :src="require('static/logo.png')" alt="picture"></image>
						<view class="zx"></view>
					</view>
					<view class="name">MyDra</view>
				</view>
		<div align="center" style="position:relative;top:100rpx;left: 50rpx;right: 50rpx;width: 650rpx;">
		    
		    	<button @click="golist" :plain="true">任务清单</button>
		</div>
        <div align="center" style="position:relative;top:110rpx;left: 50rpx;right: 50rpx;width: 650rpx;">
		    <button @click="gobian" :plain="true">便签</button>
		</div>
		<div align="center" style="position:relative;top:120rpx;left: 50rpx;right: 50rpx;width: 650rpx;">
			<button @click="gobang" :plain="true">账户关联</button>   
		</div>
		<div align="center" style="position:relative;top:130rpx;left: 50rpx;right: 50rpx;width: 650rpx;">
			<button @click="golike" :plain="true">我的喜好</button>
		</div>
	
	</view>
</template>

<script>
	export default{
		data() {
					return {
						yonghuwx: []
					}
				},
				onLoad(){
					let that = this;
					uni.login({
						provider: 'weixin',
						success: function(loginRes) {
							// 获取用户信息				
							uni.getUserInfo({
								provider: 'weixin',
								success: function(infoRes) {				
									that.yonghuwx = infoRes.userInfo
									console.log(that.yonghuwx)
								}
							});
						}
					});
				},
		methods:{
		gobian () {
			uni.navigateTo({
				url:"/pages/bianqian/bianqian"
			})
		},
		gobang () {
			uni.navigateTo({
				url:"/pages/bangding/bangding"
			})
		},
		golike () {
			uni.navigateTo({
				url:"/pages/like/like"
			})
		
		},
		golist () {
			uni.navigateTo({
				url:"/pages/list/list"
			})
		
		}
		}
	}
</script>


<style>
	.tx-w{
		margin-top:100upx;
	}
	.tx{
		text-align:center;
	}
	.tx image{
		width:200upx;
		height:200upx;
		border-radius: 200%;
	}
	
	.name{
		text-align:center;
		margin-top:20upx;
	}
</style>
