<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	page{
		background-size: 300px 500px;//设置背景大小
		background-image:url(static/beijing.png) ;//设置背景图
	}
</style>
